<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>File Diff</title>
</head>

<body>
<?php
include("lib/class.fileDiff.php");

$formGone	= (isset($_REQUEST['formGone']) && $_REQUEST['formGone'] != "")	? $_REQUEST['formGone'] : 0;

if ($formGone > 0)	{
	//	File has been uploaded
	$file1Name	= $_FILES['fileDiff1']['name'];
	$file1Tmp	= $_FILES['fileDiff1']['tmp_name'];
	$file2Name	= $_FILES['fileDiff2']['name'];
	$file2Tmp	= $_FILES['fileDiff2']['tmp_name'];
?>
	<table border="0" cellpadding="1" cellspacing="1" width="100%" bgcolor="#CCCCCC">
		<tr><td bgcolor="#EAEAEA"><a href="<?php echo $_SERVER['PHP_SELF']; ?>">back</a></td></tr>
	</table>
<?php
	$file1	= $file1Tmp;
	$file2	= $file2Tmp;
	$fDiff	= new fileDiff($file1,$file2,$file1Name,$file2Name);
	$fDiff->foundDiff();
} else {
?>
	<table border="0" cellpadding="1" cellspacing="1" width="100%" bgcolor="#CCCCCC">
		<tr>
			<td bgcolor="DADADA" colspan="2">Upload the 2 files</td>
		</tr>
		<form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
		<input type="hidden" name="formGone" value="1">
		<tr>
			<td bgcolor="#EAEAEA">1st file</td>
			<td bgcolor="#EAEAEA"><input name="fileDiff1" type="file" /></td>
		</tr>
		<tr>
			<td bgcolor="#EAEAEA">2nd file</td>
			<td bgcolor="#EAEAEA"><input name="fileDiff2" type="file" /></td>
		</tr>
		<tr>
    		<td bgcolor="#EAEAEA">&nbsp;</td>
			<td bgcolor="#EAEAEA"><input type="submit" value="Send Files" /></td>
		</tr>
		</form>
	</table>
<?php
}
?>

</body>
</html>