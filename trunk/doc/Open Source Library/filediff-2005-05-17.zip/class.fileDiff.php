<?php
#########################################################
#	GiveMeEnergy Projects				#
#	Engine by KenderThoR�	                        #
#	Contact:					#
#	kender@fastwebnet.it				#
#########################################################

/*
	$Id: class.fileDiff.php,v 1.4 2005/05/17 16:29:46 thor Exp $
*/

//require("class.showSource.php");

class fileDiff	{

	//	set both files
	//	$file1 && $file2 are the file to check
	//	$otherName1 && $otherName2 are name to give to files:
	//		ex. if you have uploaded both files, you can set a human readable name to file 
	//		(intead of something like: /tmp/phpBZnZmk)
	//		they're no mandatory!
	function fileDiff($file1,$file2,$otherName1="",$otherName2="")	{
		//	check if files exist or not
		if (!file_exists($file1))	trigger_error("File ".$file1." doesn't exist",E_USER_ERROR);
		if (!file_exists($file2))	trigger_error("File ".$file2." doesn't exist",E_USER_ERROR);
		$this->file1	= $file1;
		$this->file2	= $file2;
		$this->fileName1		= (isset($otherName1) && $otherName1 != "")	? $otherName1 : $this->file1;
		$this->fileName2		= (isset($otherName2) && $otherName2 != "")	? $otherName2 : $this->file2;
	}

	//	found difference
	function foundDiff($return = true, $caseInsensitive=false)	{
		//	read both files
		$rFile1		= $this->_readTheFile($this->file1);
		$rFile2		= $this->_readTheFile($this->file2);
		//	how many rows read
		$fCount1	= count($rFile1);
		$fCount2	= count($rFile2);
		//	diff counter
		$diffCounter	= 0;

		//	the output string
		$fDiffResult	= "";

		//	start layout
		//	used real/fake name
		$fDiffResult	.= "<table border=0 cellpadding=1 cellspacing=1 width=1000 align=\"center\">\n";
		$fDiffResult	.= "	<tr>\n";
		$fDiffResult	.= "		<td bgcolor=\"#DADADA\" width=20><strong>#</strong></td>
									<td width=490 bgcolor=\"#DADADA\"><strong>".$this->fileName1."</strong></td>
									<td width=490 bgcolor=\"#DADADA\"><strong>".$this->fileName2."</strong></td>\n";
		$fDiffResult	.= "</tr>";

		//	read 1st array and chech for diff
		$comments		= "";
		$comments2		= "";
		$commentsOpen	= 0;
		foreach ($rFile1 as $k=>$v)	{

			//	COMMENTS PATCH ( /* ... */ )
			if ($comments != "" || StriStr($v,"/*") != "")	{
				$commentsOpen	= 1;
				$comments		.= $v;
				$comments2		.= $rFile2[$k];
			}
			if (StriStr($v,"*/") != "")	{
				$commentsOpen	= 0;
				$v				= $comments;
				$rFile2[$k]		= $comments2;
				$comments		= "";
				$comments2		= "";
			}

			$check	= ($caseInsensitive)	? StriStr($v,$rFile2[$k]) : StrStr($v,$rFile2[$k]);
			if ($check != $v)	{
				$diffCounter++;
				$fDiffResult	.= "<tr>\n<td valign=\"top\">".($k+1)."</td>\n";
				if ($commentsOpen == 0)	{
					$v			= $this->_highlightString($v);
					$rFile2[$k]	= $this->_highlightString($rFile2[$k]);
					$fDiffResult	.= "<td valign=\"top\">".$v."</td><td valign=\"top\">".$rFile2[$k]."</td>\n</tr>\n";
				}

			}
		}

		//	check if 2nd file is longer than the 1st.
		//	if so, then show missing code in the 1st file
		if ($fCount2 > $fCount1)	{
			for($i=$fCount1;$i<$fCount2;$i++)	{
				$diffCounter++;
				$fDiffResult	.= "<tr>\n<td>".($i+1)."</td>\n";
				$fDiffResult	.= "<td><font color=\"#ff0000\">missing</font></td>\n
									<td>".highlight_string($rFile2[$i],true)."</td>\n</tr>\n";
			}
		}

		//	no difference found
		if ($diffCounter <=0)	{
			$fDiffResult	.= "<tr>\n<td>&nbsp;</td>\n";
			$fDiffResult	.= "<td>No differences found</td>\n<td>No differences found</td>\n</tr>\n";
		}

		//	close layout
		$fDiffResult	.= "</table>";
		if ($return)	{
			echo $fDiffResult;
		} else {
			return $fDiffResult;
		}

	}

	//	read the file and put it in an array
	function _readTheFile($file)	{
		if (file_exists($file))	{
			//$fAr	= file($file);
			$fAr	= file($file);
		} else {
			trigger_error("File doesn't exist",E_USER_ERROR);
		}
		return $fAr;
		/* another method to read file and set the array
		$fAr	= Array();
		$fp		= fopen ($file ,"r") or die ( "Impossibile to open: ".$file."");
		while(!feof($fp))	{
			$buffer		= fgets($fp,1024) ;
			$fAr[]	= $buffer;
		}
		fclose($fp);
		return $fAr;
		*/
	}

	//	Syntax Highlight
	function _highlightString($string)	{
		$string			= "<?php ".$string." ?>";
		$string			= highlight_string($string,true);
		//$string			= "<code>".$string."</code>";
		$string			= Str_Replace("&lt;?php","",$string);
		$string			= Str_Replace("?&gt;","",$string);
		//	re-edit the closing comment
		//$string			= ($comments == 1)	? Str_Replace("*/","",$string)	: $string;

		return $string;

	}
}

?>